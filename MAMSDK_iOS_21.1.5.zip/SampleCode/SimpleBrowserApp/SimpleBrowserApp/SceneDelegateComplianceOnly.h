//
//  SceneDelegateComplianceOnly.h
//  SimpleBrowserApp
//
//  Created by Jaspreet Singh on 1/14/20.
//  Copyright © 2020 Citrix Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SceneDelegateComplianceOnly : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

