//
//  AppDelegate+UISceneSupport.h
//  SimpleBrowserAppComplianceOnlyWithUIScene
//
//  Created by Jaspreet Singh on 1/14/20.
//  Copyright © 2020 Citrix Systems, Inc. All rights reserved.
//

#import "AppDelegate.h"

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate (UISceneSupport)

@end

NS_ASSUME_NONNULL_END
